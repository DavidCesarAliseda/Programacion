package U7.Cesar_FernandezAliseda_David_U7_Examen;

import java.io.Serializable;

public enum Categoria implements Serializable {
    JUNIOR,
    SENIOR,
    VETERANO
}
