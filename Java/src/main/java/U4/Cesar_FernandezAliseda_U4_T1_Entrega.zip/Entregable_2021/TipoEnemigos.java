package U4.Entregable_2021;

public enum TipoEnemigos {
    BuzzBomber,
    CrabMeat,
    Coconuts,
    Chopper,
    MotoBug
    }
