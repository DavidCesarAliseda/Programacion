package U4.Entregable_2021;

public enum TipoPersonajes {
    Sonic,
    Tails,
    Knuckles
}
