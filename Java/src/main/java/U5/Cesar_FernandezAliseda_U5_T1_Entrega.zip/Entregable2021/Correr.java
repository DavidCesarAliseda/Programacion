package U5.Entregable2021;

public interface Correr {
    public void correr();
}
