package U5.Entregable2021;

public interface Luchar {
    public  void luchar();
}
