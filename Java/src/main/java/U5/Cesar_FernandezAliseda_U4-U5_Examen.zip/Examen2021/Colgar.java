package U5.Examen2021;

public interface Colgar {
    public void colgar();
}
