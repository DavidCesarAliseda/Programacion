package U5.Examen2021;

public interface Devolver {
    public void devolver();
}
