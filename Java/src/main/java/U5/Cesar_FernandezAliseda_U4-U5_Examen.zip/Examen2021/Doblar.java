package U5.Examen2021;

public interface Doblar {
    public void doblar();
}
